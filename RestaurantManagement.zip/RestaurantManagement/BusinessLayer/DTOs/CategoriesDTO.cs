﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.DTOs
{
    public class CategoriesDTO
    {
        public string categoriName;
        public string description;

    }
}
